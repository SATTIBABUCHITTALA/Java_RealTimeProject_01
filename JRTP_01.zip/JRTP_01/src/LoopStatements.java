public class LoopStatements {

    public static void main(String args[]){ //Array {"Satti","30", "babu" }

        /*args[0] ="Satti";  ctrl+shift+/
        args[1] =30;
        args[2] ="babu";*/
        System.out.println(args[0]);

        //list of elements =====10 elements array ---args[]
        //String name[]={"sattibabu","Harsha","Kiran"};
        //name[0],name[1],------name[9];
        //String name1= "Harsha";
        //String name2="Kiran";

        //Arrays//args[0] ="Sattibabu",args[1]="EVM",args[2]="India", args[3]="Tadepalligudem";
        for(int i=0;i<args.length;i++){  //i=0--9
            if(i==2)
                break;
            System.out.println("Args values"+i+" " + args[i]);
        }
       System.out.println("Enhanced For Loop");
       for(String str:args){
           System.out.println(str);
       }




    }




}
