public class HelloWorld {
     //main method to execute the program.
    public static void main(String args[]){
        System.out.println("Hello World ");

    }


}
