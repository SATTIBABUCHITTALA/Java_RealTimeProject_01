package com.tcs.icomply.model;

//model,DTO,entity
public class StudentDetails {

    private String studentId;
    private String studentName;
    private String address;



    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "StudentDetails{" +
            "studentId='" + studentId + '\'' +
            ", studentName='" + studentName + '\'' +
            ", address='" + address + '\'' +
            '}';
    }
}
